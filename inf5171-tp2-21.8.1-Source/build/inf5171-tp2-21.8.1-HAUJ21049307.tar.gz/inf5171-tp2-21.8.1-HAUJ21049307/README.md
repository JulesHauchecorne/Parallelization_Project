Partitionnement en k-moyennes
=============================

## Dépendances

Ubuntu:

```
  apt-get install build-essential pkg-config libtbb-dev
```

Fedora:

```
  yum gcc gcc-c++ automake glibc-devel libtbb-devel
```

